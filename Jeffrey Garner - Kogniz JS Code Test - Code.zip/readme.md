#Introduction

Hello, Kogniz engineering!

My name's Jeff(rey) Garner, and I really enjoyed your test.

Just to be dutifully redundant, I would like to point to the 'index.test.js' file, where my answer to the first question has been tested with Jest.

Again, it was a pleasure, and I firmly believe that products such as the Kogniz Health Cam help to make the world a better and safer place. I would be delighted to have an opportunity to learn, grow, and contribute as a developer with your team.

My thanks and warm regards,

- Jeff

#Notes

Answers to questions 1 - 4 are in the index.js file.
A supplimentary text document version of answers has been supplied to Andrew Hilson (recruitment) via email for easier reading of verbal explanations.

#Instructions

> npm install (Jest is the sole development dependancy)

> npm test (Runs Jest in 'watchAll' mode)
